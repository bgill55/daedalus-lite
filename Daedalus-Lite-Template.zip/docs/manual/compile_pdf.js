import puppeteer from 'puppeteer';
import { marked } from 'marked';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Define paths
const rootDir = path.resolve(__dirname, '../..');
const mdPath = path.join(rootDir, 'docs/manual/setup_guide.md');
const coverPath = path.join(rootDir, 'docs/manual/daedalus_guide_cover.png');
const pdfOutputPath = path.join(rootDir, 'docs/manual/setup_guide.pdf');

async function compilePdf() {
  console.log('Starting PDF compilation...');
  if (!fs.existsSync(mdPath)) {
    console.error(`Markdown file not found at: ${mdPath}`);
    process.exit(1);
  }
  if (!fs.existsSync(coverPath)) {
    console.error(`Cover image not found at: ${coverPath}`);
    process.exit(1);
  }

  // 1. Read cover image and convert to base64
  console.log('Reading and encoding cover image...');
  const coverBase64 = fs.readFileSync(coverPath).toString('base64');

  // 2. Read and parse markdown
  console.log('Reading markdown...');
  const markdown = fs.readFileSync(mdPath, 'utf-8');
  console.log('Parsing markdown to HTML...');
  const parsedHtml = marked.parse(markdown);

  // 3. Preprocess HTML to convert Mermaid code blocks to `<div class="mermaid">`
  console.log('Converting Mermaid code blocks...');
  const htmlContent = parsedHtml.replace(/<pre><code class="language-mermaid">([\s\S]*?)<\/code><\/pre>/g, (match, code) => {
    // Decode HTML entities
    const decoded = code
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'");
    return `<div class="mermaid">${decoded}</div>`;
  });

  // 4. Construct complete HTML template with styles and Mermaid script
  const fullHtml = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Daedalus Setup Guide</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
    @page {
      size: A4;
      margin: 20mm;
    }
    @page :first {
      margin: 0;
    }
    body {
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
      color: #111827;
      line-height: 1.6;
      font-size: 11pt;
      background-color: #ffffff;
      margin: 0;
      padding: 0;
    }
    .cover-page {
      page-break-after: always;
      width: 100vw;
      height: 100vh;
      margin: 0;
      padding: 0;
      overflow: hidden;
      background-color: #0f172a;
    }
    .cover-page img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }
    .content {
      padding: 10px;
    }
    h1, h2, h3, h4 {
      color: #1e3a8a;
      font-weight: 700;
      margin-top: 1.8em;
      margin-bottom: 0.6em;
      page-break-after: avoid;
    }
    h1 {
      font-size: 26pt;
      border-bottom: 2px solid #e5e7eb;
      padding-bottom: 8px;
      margin-top: 0;
    }
    h2 {
      font-size: 18pt;
      border-bottom: 1px solid #e5e7eb;
      padding-bottom: 6px;
    }
    h3 {
      font-size: 14pt;
    }
    p {
      margin-top: 0;
      margin-bottom: 1.2em;
    }
    ul, ol {
      margin-top: 0;
      margin-bottom: 1.2em;
      padding-left: 20px;
    }
    li {
      margin-bottom: 0.4em;
    }
    code {
      font-family: 'JetBrains Mono', monospace;
      background-color: #f3f4f6;
      padding: 2px 6px;
      border-radius: 4px;
      font-size: 9.5pt;
      color: #111827;
    }
    pre {
      background-color: #1e293b;
      color: #f8fafc;
      padding: 16px;
      border-radius: 8px;
      overflow-x: auto;
      margin-top: 0;
      margin-bottom: 1.5em;
    }
    pre code {
      background-color: transparent;
      padding: 0;
      border-radius: 0;
      color: inherit;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 1.5em;
      font-size: 10pt;
    }
    th, td {
      border: 1px solid #e5e7eb;
      padding: 10px 12px;
      text-align: left;
    }
    th {
      background-color: #1e3a8a;
      color: #ffffff;
      font-weight: 600;
    }
    tr:nth-child(even) {
      background-color: #f9fafb;
    }
    strong {
      font-weight: 600;
    }
    blockquote {
      border-left: 4px solid #f59e0b;
      background-color: #fef3c7;
      padding: 12px 16px;
      margin: 0 0 1.5em 0;
      border-radius: 0 8px 8px 0;
    }
    blockquote p {
      margin: 0;
      color: #78350f;
      font-weight: 500;
    }
    hr {
      border: 0;
      border-top: 1px solid #e5e7eb;
      margin: 2em 0;
    }
    .mermaid {
      display: flex;
      justify-content: center;
      margin: 2em 0;
      background-color: #ffffff;
      padding: 16px;
      border: 1px solid #e5e7eb;
      border-radius: 8px;
    }
  </style>
</head>
<body>
  <div class="cover-page">
    <img src="data:image/png;base64,${coverBase64}" />
  </div>
  <div class="content">
    ${htmlContent}
  </div>
  <script src="https://cdn.jsdelivr.net/npm/mermaid@10.9.1/dist/mermaid.min.js"></script>
  <script>
    mermaid.initialize({
      startOnLoad: true,
      theme: 'default',
      securityLevel: 'loose'
    });
  </script>
</body>
</html>
`;

  // 5. Launch Puppeteer to render HTML and print PDF
  console.log('Launching headless browser...');
  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });
  const page = await browser.newPage();

  // Add console and request error logging
  page.on('console', msg => console.log('BROWSER LOG:', msg.text()));
  page.on('pageerror', err => console.error('BROWSER PAGE ERROR:', err.message));
  page.on('requestfailed', request => {
    console.warn(`BROWSER REQUEST FAILED: ${request.url()} - ${request.failure()?.errorText || 'unknown error'}`);
  });

  console.log('Loading content into page...');
  await page.setContent(fullHtml, { waitUntil: 'networkidle0' });

  // Wait for Mermaid to finish rendering SVG
  console.log('Waiting for Mermaid diagrams to render...');
  try {
    await page.waitForFunction(() => {
      const elements = document.querySelectorAll('.mermaid');
      if (elements.length === 0) return true;
      return Array.from(elements).every(el => el.querySelector('svg') !== null);
    }, { timeout: 15000 });
    console.log('Mermaid diagrams successfully rendered.');
  } catch (err) {
    console.warn('Timeout or error waiting for Mermaid to render. Proceeding anyway...', err);
  }

  // 6. Print PDF
  console.log('Printing PDF...');
  await page.pdf({
    path: pdfOutputPath,
    format: 'A4',
    printBackground: true,
    margin: {
      top: '20mm',
      bottom: '20mm',
      left: '20mm',
      right: '20mm'
    }
  });

  console.log(`PDF successfully created at: ${pdfOutputPath}`);
  await browser.close();
}

compilePdf().catch(err => {
  console.error('Error compiling PDF:', err);
  process.exit(1);
});