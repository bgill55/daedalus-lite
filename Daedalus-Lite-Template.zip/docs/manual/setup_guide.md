﻿# Navigate the AI Labyrinth: The Daedalus Setup Guide
*A Premium Developer Kit for Custom AI Coding Assistants* **Version:** 1.0.0 **Published:** July 2026 **Author:** Brian Gill **License:** MIT / Branded Commercial --- ## Table of Contents
1. **Overview & Architecture**
2. **Prerequisites & Setup**
3. **The InMemory Router**
4. **The Interactive REPL Shell**
5. **Branding & Customization Guidelines**
6. **Extending the CLI**
7. **Monetization & Pricing Models**
8. **NPM Publishing & Releases** --- ## 1. Overview & Architecture ### 1.1 What is Daedalus-Lite?
**Daedalus-Lite** is a lightweight, opinionated, zero-dependency starter template for building and packaging your own branded AI-powered command-line interfaces. It provides an in-memory API router, a command line interface (REPL) using Node's native readline module, and a strict TypeScript layout. This template allows developers to create a customized pair-programming terminal assistant, package it under their own brand, and sell it directly to users or clients. ### 1.2 System Architecture
The application runs entirely locally on the user's terminal, communicating directly with API endpoints (OpenAI or Anthropic) without any intermediary tracking servers. ```mermaid
sequenceDiagram autonumber actor User as Developer / CLI User participant REPL as REPL Terminal (repl.ts) participant Router as InMemoryRouter (router.ts) participant MW as Custom Middleware (types.ts) participant OpenAI as OpenAI API participant Anthropic as Claude API (Anthropic) User->>REPL: Inputs prompt / commands REPL->>Router: dispatch(ModelRequest) activate Router Router->>MW: Execute middleware chain (e.g. logging/filter) MW-->>Router: Continue to API alt OpenAI Model Selected (e.g. gpt-4) Router->>OpenAI: POST /chat/completions (unified body) OpenAI-->>Router: Return ChatCompletion JSON else Anthropic Model Selected (e.g. claude-3) Router->>Anthropic: POST /messages (Anthropic body) Anthropic-->>Router: Return Messages JSON Note over Router: Maps Anthropic response -> OpenAI format else Local / Offline Model Selected (e.g. llama3, mistral) Router->>Local: POST /chat/completions (Ollama / LM Studio) Local-->>Router: Return OpenAI-compatible JSON end Router->>Router: Save prompt & response to conversationHistory Router-->>REPL: Return unified ModelResponse JSON deactivate Router REPL->>User: Render formatted markdown output
``` --- ## 2. Prerequisites & Setup ### 2.1 System Requirements
To build and run the template, ensure your system meets the following specifications:
* **Node.js**: `v20.x` or higher (necessary for native `fetch` and ES Module loading).
* **npm**: `v10.x` or higher.
* **TypeScript**: `v5.x` or higher (installed as a development dependency). ### 2.2 Quick Start Installation
1. Initialize the project directory and install dependencies: ```bash npm install ```
2. Build the TypeScript source code: ```bash npm run build ```
3. Link the package globally to your system terminal: ```bash npm link ```
4. Run the interactive REPL: ```bash npm run repl ``` --- ## 3. The InMemory Router The core router (`src/router.ts`) is designed to handle multiple AI endpoints dynamically, mapping responses into a unified structure. ### 3.1 Mapping Schema
The router maps the different response bodies of OpenAI and Anthropic into a single unified `ModelResponse` interface: ```typescript
export interface ModelResponse { id: string; object: string; created: number; choices: Array<{ index: number; message: { role: string; content: string; }; logprobs: null | any; finish_reason: string; }>; usage: { prompt_tokens: number; completion_tokens: number; total_tokens: number; };
}
``` This guarantees that your front-end or REPL loops do not need to care which model is running; the response format remains identical. ### 3.2 Local & Offline AI Integration (Ollama & LM Studio)
By default, any model specified in the REPL (e.g. `/model llama3` or `/model deepseek-coder`) that does not start with `gpt-` or `claude-` is automatically routed as a local model. Local engines host OpenAI-compatible `/v1/chat/completions` API servers on your machine. The router queries these endpoints directly without requiring external keys: * **Ollama (Default)**: Exposes endpoints on `http://localhost:11434/v1`.
* **LM Studio**: Exposes endpoints on `http://localhost:1234/v1`. You can configure your local engine endpoint URL in your environment:
```dotenv
LOCAL_ENDPOINT_URL=http://localhost:11434/v1
``` --- ## 4. The Interactive REPL Shell The REPL (`src/repl.ts`) creates a readline session that reads inputs line-by-line. ### 4.1 Built-in Commands
The REPL recognizes the following command inputs prefixed with a `/`:
* `/help` - Displays the command manual.
* `/model <modelName>` - Swaps the active routing model (e.g., `/model gpt-4`).
* `/clear` - Empties the current session's conversation history.
* `/exit` - Terminates the process. --- ## 5. Branding & Customization Guidelines The power of `daedalus-lite` is that you can completely rebranding the tool for your target audience. ### 5.1 Color Tokens (CSS & TUI)
For web-based visual consoles, CLI text decorators, or marketing PDF documents, use the following brand tokens: | Token | Hex Value | Usage |
|---|---|---|
| **Primary Blue** | `#1E3A8A` | Headers, links, borders, branding buttons |
| **Accent Orange** | `#F59E0B` | Critical highlights, warnings, call-to-actions |
| **Background Gray** | `#F3F4F6` | Console panels, backdrop frames |
| **Primary Text** | `#111827` | Code output, main content | ### 5.2 Voice & Tone
When customizing prompt responses or error warnings, keep the voice **approachable, technical, and direct**. Avoid using emoji in standard system prints, and ensure errors provide actionable recovery tips. --- ## 6. Extending the CLI ### 6.1 Creating Custom Middleware
You can easily inject custom middleware into the request routing pipeline. This is perfect for adding logs, usage rate limits, or custom system prompts. ```typescript
// Example: System Prompt Injector Middleware
import { Middleware } from './types.js'; export const systemPromptMiddleware: Middleware = async (request, next) => { request.prompt = `Act as an expert software architect. ${request.prompt}`; return next();
};
``` Register your custom middleware by calling the router's `.use(middleware)` method. --- ## 7. Monetization & Pricing Models Selling your customized CLI can follow three distinct monetization tracks: | Tier | Price Point | Deliverable | Target Audience |
|---|---|---|---|
| **The Blueprint PDF** | `$19 - $29` | High-quality setup manual PDF + GitHub repository template access. | Indie hackers, junior developers |
| **Branded CLI Package** | `$49 - $99` | Fully pre-configured CLI compiled binaries, custom banners, custom theme. | Small developer teams |
| **CTO Integration Call** | `$249 - $499` | The manual + the branded code + a 1-hour live setup and onboarding call. | Corporate teams, agencies | --- ## 8. NPM Publishing & Releases Once you are ready to publish your template:
1. Update `package.json` with your custom name: ```json "name": "your-branded-cli" ```
2. Publish to the public NPM registry: ```bash npm publish --access public ```
3. To package the CLI into standalone executable files (no Node.js installation required for the end-user), use package compilers like `pkg`: ```bash npx pkg . --targets node18-win-x64,node18-macos-x64 ``` ---
*Navigate the AI Labyrinth with confidence.* © 2026 Brian Gill. All rights reserved.
