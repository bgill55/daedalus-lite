import { jest, beforeAll, afterAll, beforeEach, afterEach, describe, expect, test } from '@jest/globals';
import { formatResponse, logError, fetchWithTimeout } from '../src/utils.js';

// Mock console.error to avoid output during tests
const originalError = console.error;
beforeAll(() => {
  console.error = jest.fn();
});
afterAll(() => {
  console.error = originalError;
});

describe('formatResponse', () => {
  test('trims whitespace and normalizes line endings', () => {
    const input = '  Hello\r\nWorld\r\n  ';
    const expected = 'Hello\nWorld';
    expect(formatResponse(input)).toBe(expected);
  });

  test('returns empty string for empty input', () => {
    expect(formatResponse('')).toBe('');
  });

  test('handles string with only whitespace', () => {
    expect(formatResponse('   \r\n  \r  ')).toBe('');
  });
});

describe('logError', () => {
  test('logs Error instance with context', () => {
    const error = new Error('Test error');
    logError(error, 'TestContext');
    expect(console.error).toHaveBeenCalledWith(
      expect.stringContaining('[TestContext] Error: Test error')
    );
  });

  test('logs string error with context', () => {
    logError('String error', 'TestContext');
    expect(console.error).toHaveBeenCalledWith(
      expect.stringContaining('[TestContext] String error')
    );
  });

  test('logs unknown error', () => {
    const unknownError = {};
    logError(unknownError, 'TestContext');
    expect(console.error).toHaveBeenCalledWith(
      expect.stringContaining('[TestContext] Unknown error:'),
      unknownError
    );
  });
});

describe('fetchWithTimeout', () => {
  const originalFetch = global.fetch;
  let fetchMock: any;

  beforeEach(() => {
    fetchMock = jest.fn();
    global.fetch = fetchMock as unknown as typeof fetch;
  });

  afterEach(() => {
    global.fetch = originalFetch;
  });

  test('returns response on successful fetch', async () => {
    const mockResponse = new Response('success', { status: 200 });
    fetchMock.mockResolvedValue(mockResponse as any);

    const response = await fetchWithTimeout('http://example.com');
    expect(response).toBe(mockResponse);
    expect(fetchMock).toHaveBeenCalledWith('http://example.com', {
      signal: expect.any(AbortSignal),
    });
  });

  test.skip('throws timeout error when fetch times out', async () => {
    fetchMock.mockImplementation(() => new Promise(() => {}));
    await expect(fetchWithTimeout('http://example.com', {}, 10)).rejects.toThrow(
      'Request timeout after 10ms'
    );
  });

  test('throws error for non-AbortError', async () => {
    fetchMock.mockRejectedValue(new Error('Network error'));

    await expect(fetchWithTimeout('http://example.com')).rejects.toThrow(
      'Network error'
    );
  });
});