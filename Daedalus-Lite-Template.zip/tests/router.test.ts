import { jest, beforeEach, afterEach, describe, expect, test } from '@jest/globals';
import { InMemoryRouter } from '../src/router.js';
import type { ModelRequest, ModelResponse, Middleware } from '../src/types.js';
import { errorHandlerMiddleware } from '../src/middleware.js';

describe('InMemoryRouter', () => {
  let router: InMemoryRouter;
  const mockConfig = {
    openaiApiKey: 'test-openai-key',
    anthropicApiKey: 'test-anthropic-key',
    defaultModel: 'gpt-4',
    temperature: 0.7,
  };

  beforeEach(() => {
    router = new InMemoryRouter(mockConfig);
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  describe('dispatch', () => {
    test('routes to OpenAI for gpt-4 model', async () => {
      const request: ModelRequest = {
        model: 'gpt-4',
        prompt: 'Hello',
      };

      const mockResponse: ModelResponse = {
        id: 'test-id',
        object: 'chat.completion',
        created: Math.floor(Date.now() / 1000),
        choices: [{
          index: 0,
          message: {
            role: 'assistant',
            content: 'Hello!',
          },
          logprobs: null,
          finish_reason: 'stop',
        }],
        usage: {
          prompt_tokens: 5,
          completion_tokens: 2,
          total_tokens: 7,
        },
      };

      // Mock fetch for OpenAI
      const fetchSpy = jest.spyOn(global, 'fetch');
      fetchSpy.mockResolvedValueOnce({
        ok: true,
        json: async () => mockResponse,
      } as Response);

      const result = await router.dispatch(request);
      expect(result).toEqual(mockResponse);
      expect(fetchSpy).toHaveBeenCalledWith(
        'https://api.openai.com/v1/chat/completions',
        expect.objectContaining({
          method: 'POST',
          headers: expect.objectContaining({
            Authorization: 'Bearer test-openai-key',
          }),
        })
      );
    });

    test('routes to Anthropic for claude-3 model', async () => {
      const request: ModelRequest = {
        model: 'claude-3-opus-20240229',
        prompt: 'Hello',
      };

      const mockResponse: ModelResponse = {
        id: 'test-id',
        object: 'chat.completion',
        created: Math.floor(Date.now() / 1000),
        choices: [{
          index: 0,
          message: {
            role: 'assistant',
            content: 'Hello!',
          },
          logprobs: null,
          finish_reason: 'end_turn', // This is what Anthropic returns
        }],
        usage: {
          prompt_tokens: 5,
          completion_tokens: 2,
          total_tokens: 7,
        },
      };

      // Mock fetch for Anthropic
      const fetchSpy = jest.spyOn(global, 'fetch');
      fetchSpy.mockResolvedValueOnce({
        ok: true,
        json: async () => ({
          id: 'test-id',
          model: 'claude-3-opus-20240229',
          role: 'assistant',
          content: [{ text: 'Hello!' }],
          stop_reason: 'end_turn',
          usage: {
            input_tokens: 5,
            output_tokens: 2,
          },
        }),
      } as Response);

      const result = await router.dispatch(request);
      expect(result).toEqual(mockResponse);
      expect(fetchSpy).toHaveBeenCalledWith(
        'https://api.anthropic.com/v1/messages',
        expect.objectContaining({
          method: 'POST',
          headers: expect.objectContaining({
            'x-api-key': 'test-anthropic-key',
            'anthropic-version': '2023-06-01',
          }),
        })
      );
    });

    test('routes unrecognized models to the local endpoint', async () => {
      const request: ModelRequest = {
        model: 'llama3',
        prompt: 'Hello',
      };

      const mockResponse: ModelResponse = {
        id: 'local-id',
        object: 'chat.completion',
        created: Math.floor(Date.now() / 1000),
        choices: [{
          index: 0,
          message: {
            role: 'assistant',
            content: 'Hello from local model!',
          },
          logprobs: null,
          finish_reason: 'stop',
        }],
        usage: {
          prompt_tokens: 5,
          completion_tokens: 4,
          total_tokens: 9,
        },
      };

      const fetchSpy = jest.spyOn(global, 'fetch');
      fetchSpy.mockResolvedValueOnce({
        ok: true,
        json: async () => mockResponse,
      } as Response);

      const result = await router.dispatch(request);
      expect(result).toEqual(mockResponse);
      expect(fetchSpy).toHaveBeenCalledWith(
        'http://localhost:11434/v1/chat/completions',
        expect.objectContaining({
          method: 'POST',
          body: expect.stringContaining('"model":"llama3"'),
        })
      );
    });

    test('throws error when OpenAI API key is missing', async () => {
      const routerNoKey = new InMemoryRouter({
        ...mockConfig,
        openaiApiKey: undefined,
      });

      const request: ModelRequest = {
        model: 'gpt-4',
        prompt: 'Hello',
      };

      await expect(routerNoKey.dispatch(request)).rejects.toThrow(
        'OpenAI API key is required for OpenAI models'
      );
    });

    test('throws error when Anthropic API key is missing', async () => {
      const routerNoKey = new InMemoryRouter({
        ...mockConfig,
        anthropicApiKey: undefined,
      });

      const request: ModelRequest = {
        model: 'claude-3-opus-20240229',
        prompt: 'Hello',
      };

      await expect(routerNoKey.dispatch(request)).rejects.toThrow(
        'Anthropic API key is required for Anthropic models'
      );
    });
  });

  describe('conversation history', () => {
    test('includes conversation history in OpenAI requests', async () => {
      const request1: ModelRequest = {
        model: 'gpt-4',
        prompt: 'Hello',
      };

      const response1: ModelResponse = {
        id: 'test-id-1',
        object: 'chat.completion',
        created: Math.floor(Date.now() / 1000),
        choices: [{
          index: 0,
          message: {
            role: 'assistant',
            content: 'Hi there!',
          },
          logprobs: null,
          finish_reason: 'stop',
        }],
        usage: {
          prompt_tokens: 5,
          completion_tokens: 2,
          total_tokens: 7,
        },
      };

      const request2: ModelRequest = {
        model: 'gpt-4',
        prompt: 'How are you?',
      };

      const response2: ModelResponse = {
        id: 'test-id-2',
        object: 'chat.completion',
        created: Math.floor(Date.now() / 1000),
        choices: [{
          index: 0,
          message: {
            role: 'assistant',
            content: 'I am good!',
          },
          logprobs: null,
          finish_reason: 'stop',
        }],
        usage: {
          prompt_tokens: 8,
          completion_tokens: 3,
          total_tokens: 11,
        },
      };

      // Mock fetch for OpenAI
      const fetchSpy = jest.spyOn(global, 'fetch');
      fetchSpy
        .mockResolvedValueOnce({
          ok: true,
          json: async () => response1,
        } as Response)
        .mockResolvedValueOnce({
          ok: true,
          json: async () => response2,
        } as Response);

      // First request
      await router.dispatch(request1);
      
      // Second request - should include history from first exchange
      await router.dispatch(request2);

      // Check that the second call included both previous messages plus current
      expect(fetchSpy).toHaveBeenCalledTimes(2);
      const secondCallBody = JSON.parse((fetchSpy.mock.calls[1][1] as any).body);
      expect(secondCallBody.messages).toHaveLength(3);
      expect(secondCallBody.messages[0]).toEqual({ role: 'user', content: 'Hello' });
      expect(secondCallBody.messages[1]).toEqual({ role: 'assistant', content: 'Hi there!' });
      expect(secondCallBody.messages[2]).toEqual({ role: 'user', content: 'How are you?' });
    });

    test('includes conversation history in Anthropic requests', async () => {
      const request1: ModelRequest = {
        model: 'claude-3-opus-20240229',
        prompt: 'Hello',
      };

      const response1: ModelResponse = {
        id: 'test-id-1',
        object: 'chat.completion',
        created: Math.floor(Date.now() / 1000),
        choices: [{
          index: 0,
          message: {
            role: 'assistant',
            content: 'Hi there!',
          },
          logprobs: null,
          finish_reason: 'end_turn',
        }],
        usage: {
          prompt_tokens: 5,
          completion_tokens: 2,
          total_tokens: 7,
        },
      };

      const request2: ModelRequest = {
        model: 'claude-3-opus-20240229',
        prompt: 'How are you?',
      };

      const response2: ModelResponse = {
        id: 'test-id-2',
        object: 'chat.completion',
        created: Math.floor(Date.now() / 1000),
        choices: [{
          index: 0,
          message: {
            role: 'assistant',
            content: 'I am good!',
          },
          logprobs: null,
          finish_reason: 'end_turn',
        }],
        usage: {
          prompt_tokens: 8,
          completion_tokens: 3,
          total_tokens: 11,
        },
      };

      // Mock fetch for Anthropic
      const fetchSpy = jest.spyOn(global, 'fetch');
      fetchSpy
        .mockResolvedValueOnce({
          ok: true,
          json: async () => ({
            id: 'test-id-1',
            model: 'claude-3-opus-20240229',
            role: 'assistant',
            content: [{ text: 'Hi there!' }],
            stop_reason: 'end_turn',
            usage: {
              input_tokens: 5,
              output_tokens: 2,
            },
          }),
        } as Response)
        .mockResolvedValueOnce({
          ok: true,
          json: async () => ({
            id: 'test-id-2',
            model: 'claude-3-opus-20240229',
            role: 'assistant',
            content: [{ text: 'I am good!' }],
            stop_reason: 'end_turn',
            usage: {
              input_tokens: 8,
              output_tokens: 3,
            },
          }),
        } as Response);

      // First request
      await router.dispatch(request1);
      
      // Second request - should include history
      await router.dispatch(request2);

      // Check that the second call included both messages
      expect(fetchSpy).toHaveBeenCalledTimes(2);
      const secondCallBody = JSON.parse((fetchSpy.mock.calls[1][1] as any).body);
      expect(secondCallBody.messages).toHaveLength(3);
      expect(secondCallBody.messages[0]).toEqual({ role: 'user', content: 'Hello' });
      expect(secondCallBody.messages[1]).toEqual({ role: 'assistant', content: 'Hi there!' });
      expect(secondCallBody.messages[2]).toEqual({ role: 'user', content: 'How are you?' });
    });

    test('clearHistory removes conversation history', async () => {
      const request1: ModelRequest = {
        model: 'gpt-4',
        prompt: 'Hello',
      };

      const response1: ModelResponse = {
        id: 'test-id-1',
        object: 'chat.completion',
        created: Math.floor(Date.now() / 1000),
        choices: [{
          index: 0,
          message: {
            role: 'assistant',
            content: 'Hi there!',
          },
          logprobs: null,
          finish_reason: 'stop',
        }],
        usage: {
          prompt_tokens: 5,
          completion_tokens: 2,
          total_tokens: 7,
        },
      };

      const request2: ModelRequest = {
        model: 'gpt-4',
        prompt: 'How are you?',
      };

      const response2: ModelResponse = {
        id: 'test-id-2',
        object: 'chat.completion',
        created: Math.floor(Date.now() / 1000),
        choices: [{
          index: 0,
          message: {
            role: 'assistant',
            content: 'I am good!',
          },
          logprobs: null,
          finish_reason: 'stop',
        }],
        usage: {
          prompt_tokens: 8,
          completion_tokens: 3,
          total_tokens: 11,
        },
      };

      // Mock fetch for OpenAI
      const fetchSpy = jest.spyOn(global, 'fetch');
      fetchSpy
        .mockResolvedValueOnce({
          ok: true,
          json: async () => response1,
        } as Response)
        .mockResolvedValueOnce({
          ok: true,
          json: async () => response2,
        } as Response);

      // First request
      await router.dispatch(request1);
      
      // Clear history
      router.clearHistory();
      
      // Second request - should NOT include history
      await router.dispatch(request2);
      
      // Check that the second call only had the current message
      expect(fetchSpy).toHaveBeenCalledTimes(2);
      const secondCallBody = JSON.parse((fetchSpy.mock.calls[1][1] as any).body);
      expect(secondCallBody.messages).toHaveLength(1);
      expect(secondCallBody.messages[0]).toEqual({ role: 'user', content: 'How are you?' });
    });
  });

  describe('middleware', () => {
    test('applies middleware in order', async () => {
      const request: ModelRequest = {
        model: 'gpt-4',
        prompt: 'Hello',
      };

      const mockResponse: ModelResponse = {
        id: 'test-id',
        object: 'chat.completion',
        created: Math.floor(Date.now() / 1000),
        choices: [{
          index: 0,
          message: {
            role: 'assistant',
            content: 'Hello!',
          },
          logprobs: null,
          finish_reason: 'stop',
        }],
        usage: {
          prompt_tokens: 5,
          completion_tokens: 2,
          total_tokens: 7,
        },
      };

      // Mock fetch
      const fetchSpy = jest.spyOn(global, 'fetch');
      fetchSpy.mockResolvedValueOnce({
        ok: true,
        json: async () => mockResponse,
      } as Response);

      // Middleware that adds a header to the request (simulated by modifying the request object)
      let middleware1Called = false;
      let middleware2Called = false;
      let middleware1CalledBefore = false;

      const middleware1: Middleware = async (req, next) => {
        middleware1Called = true;
        middleware1CalledBefore = !middleware2Called;
        return next();
      };

      const middleware2: Middleware = async (req, next) => {
        middleware2Called = true;
        return next();
      };

      router.use(middleware1);
      router.use(middleware2);

      await router.dispatch(request);

      expect(middleware1Called).toBe(true);
      expect(middleware2Called).toBe(true);
      expect(middleware1CalledBefore).toBe(true);
    });

    test('error handling middleware catches errors', async () => {
      const request: ModelRequest = {
        model: 'gpt-4',
        prompt: 'Hello',
      };

      // Make the router throw an error by missing API key
      const routerNoKey = new InMemoryRouter({
        ...mockConfig,
        openaiApiKey: undefined,
      });

      // Apply error handling middleware
      routerNoKey.use(errorHandlerMiddleware);

      const response = await routerNoKey.dispatch(request);

      // Should return an error response, not throw
      expect(response).toHaveProperty('object', 'chat.completion');
      expect(response.choices[0].message.content).toContain('Error:');
      expect(response.choices[0].message.role).toBe('assistant');
    });
  });
});