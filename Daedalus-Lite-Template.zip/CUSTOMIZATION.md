# Daedalus-Lite Customization & Rebranding Guide

Welcome to **Daedalus-Lite**! This guide walks you through customizing, rebranding, extending, and compiling your own commercial AI CLI tool.

---

## 1. Rebranding Your CLI

### Change the CLI Name & Prompt

Open `src/repl.ts` and modify the prompt string:

```typescript
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  prompt: 'myai> ', // Change 'daedalus> ' to your brand prompt!
});
```

### Update Default Configurations

Open `src/index.ts` to customize default parameters and environment variable names:

```typescript
export const defaultConfig: RouterConfig = {
  openaiApiKey: process.env.MYAI_OPENAI_KEY || process.env.OPENAI_API_KEY,
  anthropicApiKey: process.env.MYAI_ANTHROPIC_KEY || process.env.ANTHROPIC_API_KEY,
  localEndpointUrl: process.env.LOCAL_ENDPOINT_URL || 'http://localhost:11434/v1',
  defaultModel: 'gpt-4o',
  temperature: 0.7,
};
```

---

## 2. Adding Custom Middleware

Daedalus-Lite includes an extensible middleware chain pattern. You can register custom middleware in `src/index.ts`.

### Example: Logging Prompt Tokens

Create a middleware function in `src/middleware.ts`:

```typescript
import type { Middleware } from './types.js';

export const loggerMiddleware: Middleware = async (req, next) => {
  console.log(`[LOG] Prompt sent to ${req.model}: "${req.prompt.slice(0, 40)}..."`);
  const response = await next(req);
  return response;
};
```

Register it in `src/index.ts`:

```typescript
import { loggerMiddleware } from './middleware.js';

defaultRouter.use(loggerMiddleware);
```

---

## 3. Adding New LLM Providers

To add a new AI provider (e.g. Groq, Mistral, Together AI, or a custom internal API), open `src/router.ts` and add a dispatcher method:

```typescript
private async dispatchToGroq(request: ModelRequest): Promise<ModelResponse> {
  const apiKey = process.env.GROQ_API_KEY;
  const res = await fetchWithTimeout('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: request.model,
      messages: this.buildMessages(request.prompt),
    }),
  });
  return res.json();
}
```

Then hook it up inside `dispatch()`:

```typescript
if (request.model.startsWith('llama-3') || request.model.startsWith('mixtral')) {
  return this.dispatchToGroq(request);
}
```

---

## 4. Building Standalone Executables

Want to ship your CLI as a single pre-compiled binary so your customers don't even need Node.js installed?

### Option A: Using `bun build` (Fastest)

If you use [Bun](https://bun.sh):

```bash
bun build --compile --target=bun-windows-x64 ./src/index.ts --outfile myai.exe
bun build --compile --target=bun-darwin-arm64 ./src/index.ts --outfile myai-macos
```

### Option B: Using `pkg` or SEA

You can also package using Node single-executable applications (SEA):

```bash
npx pkg . --targets node18-win-x64,node18-macos-x64
```

---

## 5. Testing Your Changes

Always run the test suite after adding new features:

```bash
npm test
```

Build the TypeScript compiler output:

```bash
npm run build
```

Test the interactive REPL locally:

```bash
npm run repl
```

---

## 6. Going Further — White-Glove Service

You've got the template running. You've rebranded it. But maybe you want more:

- **Custom integrations** — hook it into your existing tools, databases, or APIs
- **Multi-agent orchestration** — planner, coder, reviewer, debugger agents working together
- **Codebase indexing** — FTS5 symbol search across your project
- **TUI dashboard** — live CPU/RAM gauges, session management, the works
- **Full product build** — from template to shippable binary with your brand, your pricing, your docs

This is where we come in. We built the flagship Daedalus on this exact foundation. We can build yours too.

[Book a white-glove consultation](mailto:bricam55@gmail.com?subject=White-Glove%20Setup%20Inquiry) — one hour, flat rate, no upsells.

---

*Need help or enterprise support? Contact `bricam55@gmail.com`.*