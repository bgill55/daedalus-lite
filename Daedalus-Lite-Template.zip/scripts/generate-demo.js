﻿import { writeFileSync } from 'fs';
import { resolve, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Terminal Demo</title>
<style> * { margin: 0; padding: 0; box-sizing: border-box; } body { background: #0F172A; display: flex; align-items: center; justify-content: center; min-height: 100vh; font-family: "Cascadia Code", "Fira Code", "JetBrains Mono", "Consolas", monospace; padding: 20px; } .terminal { background: #1E293B; border-radius: 12px; box-shadow: 0 20px 60px rgba(0,0,0,0.5); width: 780px; overflow: hidden; border: 1px solid #334155; } .terminal-header { background: #1E293B; padding: 12px 16px; display: flex; align-items: center; gap: 8px; border-bottom: 1px solid #334155; } .dot { width: 12px; height: 12px; border-radius: 50%; } .dot.red { background: #EF4444; } .dot.yellow { background: #F59E0B; } .dot.green { background: #10B981; } .terminal-body { padding: 20px 24px; font-family: "Cascadia Code", "Fira Code", "JetBrains Mono", "Consolas", monospace; font-size: 14px; line-height: 1.7; color: #E2E8F0; background: #0F172A; } .line { white-space: pre-wrap; word-break: break-all; } .prompt { color: #10B981; } .cmd { color: #E2E8F0; } .output { color: #94A3B8; } .output-green { color: #34D399; } .output-blue { color: #60A5FA; } .cursor { display: inline-block; width: 8px; height: 16px; background: #10B981; animation: blink 1s step-end infinite; vertical-align: text-bottom; margin-left: 2px; } @keyframes blink { 50% { opacity: 0; } } .spacer { height: 4px; }
</style>
</head>
<body>
<div class="terminal"> <div class="terminal-header"> <div class="dot red"></div> <div class="dot yellow"></div> <div class="dot green"></div> <span style="color:#64748B;font-family:Inter,sans-serif;font-size:13px;margin-left:8px;">daedalus-lite — REPL</span> </div> <div class="terminal-body"> <div class="line"><span class="prompt">daedalus&gt;</span> <span class="cmd">/help</span></div> <div class="line output">Available commands:</div> <div class="line output"> /help - Show this help message</div> <div class="line output"> /model &lt;modelName&gt; - Set the model for subsequent requests</div> <div class="line output"> /clear - Clear conversation history</div> <div class="line output"> /exit - Exit the REPL</div> <div class="spacer"></div> <div class="line"><span class="prompt">daedalus&gt;</span> <span class="cmd">/model claude-sonnet-4-20250514</span></div> <div class="line output-green">Model set to: claude-sonnet-4-20250514</div> <div class="spacer"></div> <div class="line"><span class="prompt">daedalus&gt;</span> <span class="cmd">Write a quick fibonacci function in Python</span></div> <div class="spacer"></div> <div class="line output">Here is a recursive Fibonacci function in Python:</div> <div class="line output-blue"> def fib(n):</div> <div class="line output-blue"> if n &lt;= 1:</div> <div class="line output-blue"> return n</div> <div class="line output-blue"> return fib(n-1) + fib(n-2)</div> <div class="line output">For better performance with larger values, use memoization or iteration.</div> <div class="spacer"></div> <div class="line"><span class="prompt">daedalus&gt;</span> <span class="cmd">/clear</span></div> <div class="line output-green">Conversation history cleared.</div> <div class="spacer"></div> <div class="line"><span class="prompt">daedalus&gt;</span> <span class="cursor"></span></div> </div>
</div>
</body>
</html>`;

const outputPath = resolve(__dirname, '..', 'docs', 'terminal-demo.html');
writeFileSync(outputPath, html, 'utf-8');
console.log(`Generated ${outputPath}`);