import puppeteer from 'puppeteer';
import { resolve, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));

const browser = await puppeteer.launch({ headless: true, args: ['--no-sandbox'] });
const page = await browser.newPage();
await page.setViewport({ width: 900, height: 700 });

const filePath = 'file://' + resolve(__dirname, '..', 'docs', 'terminal-demo.html');
await page.goto(filePath, { waitUntil: 'networkidle0' });
await new Promise(r => setTimeout(r, 1000));

const terminal = await page.$('.terminal');
await terminal.screenshot({ path: resolve(__dirname, '..', 'docs', 'terminal-screenshot.png') });
await browser.close();
console.log('Screenshot saved!');