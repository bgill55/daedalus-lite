/** (c) 2026 Brian Gill (bgill55). Daedalus-Lite. All rights reserved. */

/**
 * Format a model response for display in the REPL
 */
export function formatResponse(response: string): string {
  // Trim whitespace and normalize line endings
  const trimmed = response.trim();
  // Ensure consistent line endings
  const normalized = trimmed.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  return normalized;
}

/**
 * Log an error with consistent formatting
 */
export function logError(error: unknown, context?: string): void {
  const timestamp = new Date().toISOString();
  const prefix = context ? `[${context}] ` : '';
  
  if (error instanceof Error) {
    console.error(`${timestamp} ${prefix}${error.name}: ${error.message}`);
  } else if (typeof error === 'string') {
    console.error(`${timestamp} ${prefix}${error}`);
  } else {
    console.error(`${timestamp} ${prefix}Unknown error:`, error);
  }
}

/**
 * Fetch with timeout support
 * @param url - The URL to fetch
 * @param options - Fetch options
 * @param timeoutMs - Timeout in milliseconds (default: 30000)
 * @returns Promise with the fetch response
 * @throws Error if timeout is reached or fetch fails
 */
export async function fetchWithTimeout(
  url: string,
  options: RequestInit = {},
  timeoutMs: number = 30000
): Promise<Response> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal,
    });
    return response;
  } catch (error) {
    if (error instanceof Error && error.name === 'AbortError') {
      throw new Error(`Request timeout after ${timeoutMs}ms`);
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }
}