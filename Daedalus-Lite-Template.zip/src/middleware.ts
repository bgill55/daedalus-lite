/** (c) 2026 Brian Gill (bgill55). Daedalus-Lite. All rights reserved. */

import type { ModelRequest, ModelResponse, RouterConfig } from './types.js';

// Error handling middleware
export const errorHandlerMiddleware = async (req: ModelRequest, next: () => Promise<ModelResponse>): Promise<ModelResponse> => {
  try {
    return await next();
  } catch (error) {
    // Return a standardized error response
    return {
      id: `error-${Date.now()}`,
      object: 'chat.completion',
      created: Math.floor(Date.now() / 1000),
      choices: [{
        index: 0,
        message: {
          role: 'assistant',
          content: `Error: ${error instanceof Error ? error.message : String(error)}`
        },
        logprobs: null,
        finish_reason: 'error'
      }],
      usage: {
        prompt_tokens: 0,
        completion_tokens: 0,
        total_tokens: 0
      }
    };
  }
};