/** (c) 2026 Brian Gill (bgill55). Daedalus-Lite. All rights reserved. */

import * as readline from 'node:readline';
import { InMemoryRouter } from './router.js';
import type { ModelRequest, ModelResponse, RouterConfig } from './types.js';

export function startRepl(router: InMemoryRouter, defaultModel: string): void {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: 'daedalus> ',
  });

  let currentModel: string | undefined = undefined;

  rl.prompt();

  rl.on('line', (line) => {
    const input = line.trim();

    if (input.startsWith('/')) {
      const [command, ...args] = input.slice(1).split(/\s+/);
      switch (command) {
        case 'help':
          console.log(`
Available commands:
  /help     - Show this help message
  /model <modelName> - Set the model for subsequent requests (e.g., /model gpt-4)
  /clear    - Clear conversation history
  /exit     - Exit the REPL
          `.trim());
          break;
        case 'model':
          if (args.length === 0) {
            console.log('Please specify a model name. Example: /model gpt-4');
          } else {
            currentModel = args[0];
            console.log(`Model set to: ${currentModel}`);
          }
          break;
        case 'clear':
          router.clearHistory();
          console.log('Conversation history cleared.');
          break;
        case 'exit':
          rl.close();
          process.exit(0);
          break;
        default:
          console.log(`Unknown command: ${command}. Type /help for available commands.`);
          break;
      }
    } else if (input.length > 0) {
      const request: ModelRequest = {
        prompt: input,
        model: currentModel ?? defaultModel,
      };

      router.dispatch(request)
        .then((response) => {
          if (response.choices?.[0]?.message?.content) {
            console.log(response.choices[0].message.content);
          } else {
            console.log('Received unexpected response format:', JSON.stringify(response, null, 2));
          }
        })
        .catch((error) => {
          console.error('Error:', error.message);
        })
        .finally(() => {
          rl.prompt();
        });
    } else {
      rl.prompt();
    }
  });

  rl.on('close', () => {
    process.exit(0);
  });
}