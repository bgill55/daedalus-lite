/** (c) 2026 Brian Gill (bgill55). Daedalus-Lite. All rights reserved. */

import { InMemoryRouter } from './router.js';
import { startRepl } from './repl.js';
import type { ModelRequest, ModelResponse, RouterConfig } from './types.js';
import { errorHandlerMiddleware } from './middleware.js';

// Load environment variables from .env file
import dotenv from 'dotenv';
dotenv.config();

export const defaultConfig: RouterConfig = {
  openaiApiKey: process.env.OPENAI_API_KEY,
  anthropicApiKey: process.env.ANTHROPIC_API_KEY,
  localEndpointUrl: process.env.LOCAL_ENDPOINT_URL || 'http://localhost:11434/v1',
  defaultModel: 'gpt-4',
  temperature: 0.7,
};

export const defaultRouter = new InMemoryRouter(defaultConfig);
defaultRouter.use(errorHandlerMiddleware);

export { InMemoryRouter } from './router.js';
export { startRepl } from './repl.js';
export { errorHandlerMiddleware } from './middleware.js';
export type { ModelRequest, ModelResponse, RouterConfig } from './types.js';