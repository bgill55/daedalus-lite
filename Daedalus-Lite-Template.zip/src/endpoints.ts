/** (c) 2026 Brian Gill (bgill55). Daedalus-Lite. All rights reserved. */

export const OPENAI_ENDPOINT = 'https://api.openai.com/v1';
export const ANTHROPIC_ENDPOINT = 'https://api.anthropic.com/v1';