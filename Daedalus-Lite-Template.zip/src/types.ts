/** (c) 2026 Brian Gill (bgill55). Daedalus-Lite. All rights reserved. */

export interface ModelRequest {
  model: string;
  prompt: string;
  temperature?: number;
}

export interface ModelResponse {
  id: string;
  object: string;
  created: number;
  choices: Array<{
    index: number;
    message: {
      role: string;
      content: string;
    };
    logprobs: null | any;
    finish_reason: string;
  }>;
  usage: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
}

export interface RouterConfig {
  openaiApiKey?: string;
  anthropicApiKey?: string;
  localEndpointUrl?: string;
  defaultModel: string;
  temperature: number;
}

export interface Middleware {
  (req: ModelRequest, next: () => Promise<ModelResponse>): Promise<ModelResponse>;
}