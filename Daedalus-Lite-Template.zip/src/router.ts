/** (c) 2026 Brian Gill (bgill55). Daedalus-Lite. All rights reserved. */

import type { ModelRequest, ModelResponse, RouterConfig, Middleware } from './types.js';
import { OPENAI_ENDPOINT, ANTHROPIC_ENDPOINT } from './endpoints.js';
import { fetchWithTimeout } from './utils.js';

export class InMemoryRouter {
  private config: RouterConfig;
  private middleware: Middleware[] = [];
  private conversationHistory: { role: string; content: string }[] = [];

  constructor(config: RouterConfig) {
    this.config = config;
  }

  // Add middleware to the chain
  use(middleware: Middleware): void {
    this.middleware.push(middleware);
  }

  // Clear conversation history
  clearHistory(): void {
    this.conversationHistory = [];
  }

  async dispatch(request: ModelRequest): Promise<ModelResponse> {
    const model = request.model || this.config.defaultModel;
    const temperature = request.temperature ?? this.config.temperature;

    // Build messages array: history + current user message
    const userMessage = { role: 'user', content: request.prompt };
    const messages = [...this.conversationHistory, userMessage];

    // Create the final handler that will actually dispatch to the AI service
    const finalHandler = async (): Promise<ModelResponse> => {
      let response: ModelResponse;
      if (model.startsWith('gpt-') || model.startsWith('o1-')) {
        response = await this.dispatchToOpenAI({ model, temperature, messages });
      } else if (model.startsWith('claude-')) {
        response = await this.dispatchToAnthropic({ model, temperature, messages });
      } else {
        response = await this.dispatchToLocal({ model, temperature, messages });
      }
      this.conversationHistory.push(userMessage, { role: 'assistant', content: response.choices[0].message.content });
      return response;
    };

    // Execute middleware chain
    let index = 0;
    const next = async (): Promise<ModelResponse> => {
      if (index < this.middleware.length) {
        const middleware = this.middleware[index++];
        return middleware(request, next);
      }
      return finalHandler();
    };

    return next();
  }

  private async dispatchToOpenAI(request: { model: string; temperature: number; messages: { role: string; content: string }[] }): Promise<ModelResponse> {
    if (!this.config.openaiApiKey) {
      throw new Error('OpenAI API key is required for OpenAI models');
    }

    const response = await fetchWithTimeout(`${OPENAI_ENDPOINT}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.config.openaiApiKey}`,
      },
      body: JSON.stringify({
        model: request.model,
        messages: request.messages,
        temperature: request.temperature,
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`OpenAI API error: ${response.status} - ${error}`);
    }

    const data = await response.json();
    return data;
  }

  private async dispatchToAnthropic(request: { model: string; temperature: number; messages: { role: string; content: string }[] }): Promise<ModelResponse> {
    if (!this.config.anthropicApiKey) {
      throw new Error('Anthropic API key is required for Anthropic models');
    }

    // Anthropic expects alternating user/assistant messages ending with user
    // Our conversation history already alternates, so we send the whole array.

    const response = await fetchWithTimeout(`${ANTHROPIC_ENDPOINT}/messages`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': this.config.anthropicApiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: request.model,
        max_tokens: 4096,
        messages: request.messages,
        temperature: request.temperature,
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Anthropic API error: ${response.status} - ${error}`);
    }

    const anthropicResponse = await response.json();

    // Convert Anthropic response to our ModelResponse format
    return {
      id: anthropicResponse.id,
      object: 'chat.completion',
      created: Math.floor(Date.now() / 1000),
      choices: [{
        index: 0,
        message: {
          role: anthropicResponse.role, // This is usually 'assistant'
          content: anthropicResponse.content[0].text,
        },
        logprobs: null,
        finish_reason: anthropicResponse.stop_reason,
      }],
      usage: {
        prompt_tokens: anthropicResponse.usage.input_tokens,
        completion_tokens: anthropicResponse.usage.output_tokens,
        total_tokens: anthropicResponse.usage.input_tokens + anthropicResponse.usage.output_tokens,
      },
    };
  }

  private async dispatchToLocal(request: { model: string; temperature: number; messages: { role: string; content: string }[] }): Promise<ModelResponse> {
    const endpoint = this.config.localEndpointUrl || 'http://localhost:11434/v1';
    
    const response = await fetchWithTimeout(`${endpoint.replace(/\/$/, '')}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: request.model,
        messages: request.messages,
        temperature: request.temperature,
      }),
    });
 
    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Local AI API error: ${response.status} - ${error}`);
    }
 
    const data = await response.json();
    return data;
  }
}