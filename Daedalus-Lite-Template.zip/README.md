# Daedalus-Lite Template

Congratulations on your purchase! You now have access to the Daedalus-Lite template source code.

<p align="center">
  <img src="docs/manual/daedalus_lite_logo.png" alt="Daedalus-Lite Logo" width="200"/>
</p>

## What you get

- Complete TypeScript source code (~300 lines)
- Build scripts (`npm run build`)
- REPL (`npm run repl`)
- Dev server (`npm start`)
- Test suite (`npm test`)
- All configuration files (tsconfig, jest, etc.)

## What you need to do

1. **Clone this repository** (you already have access)
2. **Run `npm install`** to install the only runtime dependency: `dotenv`
3. **Run `npm run build`** to compile the TypeScript
4. **Run `npm run repl`** to start chatting with your AI
5. **Rebrand & Customize** - Follow the step-by-step [CUSTOMIZATION.md](CUSTOMIZATION.md) guide to rebrand, add middleware, or package binaries
6. **Sell it** - you own your derivative code, set your price, keep 100% of profits

## License

This template is provided under a **Branded Commercial License**. As the owner of this code, you may:
- Use the code to build commercial products
- Modify the code
- Distribute compiled binaries
- Sell your branded version

You may not:
- Resell or redistribute this template as-is
- Claim the template as your own work
- Remove the original copyright notice

See the full license in the source files.

## Support

If you purchased the Pro or Enterprise tier, you have access to email support and/or setup help. Contact the email provided in your purchase confirmation.

### Need more than the template?

Daedalus-Lite gives you a solid foundation, but turning a CLI into a polished product takes more than code. If you hit a wall — custom integrations, white-glove branding, multi-agent features, or just want someone to handle the whole build — that's what we do.

[Book a white-glove consultation](mailto:bricam55@gmail.com?subject=White-Glove%20Setup%20Inquiry) — we'll handle the heavy lifting so you can focus on selling.

Happy hacking!